import bcrypt
import pymongo
from flask import Flask, redirect, request, session, url_for

app = Flask(__name__)
app.secret_key = "task"
client = pymongo.MongoClient(
    "mongodb+srv://task:sarim123@cluster0.rjskfy3.mongodb.net/?retryWrites=true&w=majority"
)
db = client.get_database("records")
records = db.register
templates = db.template


@app.route("/register", methods=["post"])
def index():
    message = ""
    if "email" in session:
        return redirect(url_for("logged_in"))
    if request.method == "POST":
        f_user = request.form.get("first_name")
        l_user = request.form.get("last_name")
        user = f"{f_user} {l_user}"
        email = request.form.get("email")

        password = request.form.get("password")

        user_found = records.find_one({"name": user})
        email_found = records.find_one({"email": email})
        if user_found:
            message = "There already is a user by that name"
            return message
        if email_found:
            message = "This email already exists in database"
            return message
        else:
            hashed = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())
            user_input = {"name": user, "email": email, "password": hashed}
            records.insert_one(user_input)

            user_data = records.find_one({"email": email})
            new_email = user_data["email"]

            return "User created successfully"
    return message


@app.route("/logged_in")
def logged_in():
    if "email" not in session:
        return "You are not logged in"
    email = session["email"]
    return {"Result": f"Welcome {email}"}


@app.route("/login", methods=["POST"])
def login():
    message = "Please login to your account"
    if "email" in session:
        return redirect(url_for("logged_in"))

    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        if email_found := records.find_one({"email": email}):
            email_val = email_found["email"]
            passwordcheck = email_found["password"]

            if bcrypt.checkpw(password.encode("utf-8"), passwordcheck):
                session["email"] = email_val
                return redirect(url_for("logged_in"))
            else:
                if "email" in session:
                    return redirect(url_for("logged_in"))
                message = "Wrong password"
                return message
        else:
            message = "Email not found"
            return message
    return message


@app.route("/logout", methods=["POST", "GET"])
def logout():
    if "email" not in session:
        return "You are not logged in"
    email = session["email"]
    session.pop("email", None)
    return f"logged out {email}"


@app.route("/template", methods=["POST", "GET"])
def template():
    if "email" not in session:
        return "You are not logged in"
    email = session["email"]
    if request.method == "POST":
        template = request.form["template"]
        subject = request.form["subject"]
        body = request.form["body"]
        templates.insert_one(
            {"email": email, "template": template, "subject": subject, "body": body}
        )
        return redirect(url_for("template"))
    else:
        if template := templates.find_one(
            {
                "email": email,
                "template": request.form["template"],
                "subject": request.form["subject"],
                "body": request.form["body"],
            }
        ):
            template = template["template"]
            return template
        else:
            temps = templates.find({"email": email})
            return [temp.get("template") for temp in temps]


@app.route("/delete-template", methods=["POST", "GET"])
def delete_template():
    if "email" not in session:
        return "You are not logged in"
    if request.method == "POST":
        email = session["email"]
        template = request.form["template"]
        templates.delete_one({"email": email, "template": template})
        return redirect(url_for("template"))
    return "Template Deleted"


@app.route("/edit-template", methods=["POST"])
def edit_template():
    if "email" not in session:
        return "You are not logged in"
    if request.method == "POST":
        email = session["email"]
        template = request.form["template"]
        if not email or template:
            return "Please fill all the fields"
        find_one = {"email": email, "template": template}
        update_this = {
            "$set": {
                "template": request.form["new_template"],
                "subject": request.form["new_subject"],
                "body": request.form["new_body"],
            }
        }
        templates.update_one(find_one, update_this)
        return redirect(url_for("template"))
    return "Template Edited"


# end of code to run it
if __name__ == "__main__":
    app.run(debug=True, port=5000)
