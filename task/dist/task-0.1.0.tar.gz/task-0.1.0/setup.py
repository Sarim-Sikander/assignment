# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['task']

package_data = \
{'': ['*']}

install_requires = \
['Flask>=2.2.2,<3.0.0',
 'bcrypt>=4.0.0,<5.0.0',
 'pymongo>=4.2.0,<5.0.0',
 'pytest>=7.1.3,<8.0.0']

entry_points = \
{'console_scripts': ['task = task:app']}

setup_kwargs = {
    'name': 'task',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Sarim-Sikander',
    'author_email': 'sarimsikander24@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
